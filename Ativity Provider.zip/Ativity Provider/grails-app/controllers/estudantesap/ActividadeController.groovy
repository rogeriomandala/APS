package estudantesap

import grails.validation.ValidationException
import static org.springframework.http.HttpStatus.*

class ActividadeController {

    ActividadeService actividadeService

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond actividadeService.list(params), model:[actividadeCount: actividadeService.count()]
    }

    def show(Long id) {
        respond actividadeService.get(id)
    }

    def create() {
        respond new Actividade(params)
    }

    def save(Actividade actividade) {
        if (actividade == null) {
            notFound()
            return
        }

        try {
            actividadeService.save(actividade)
        } catch (ValidationException e) {
            respond actividade.errors, view:'create'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'actividade.label', default: 'Actividade'), actividade.id])
                redirect actividade
            }
            '*' { respond actividade, [status: CREATED] }
        }
    }

    def edit(Long id) {
        respond actividadeService.get(id)
    }

    def update(Actividade actividade) {
        if (actividade == null) {
            notFound()
            return
        }

        try {
            actividadeService.save(actividade)
        } catch (ValidationException e) {
            respond actividade.errors, view:'edit'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'actividade.label', default: 'Actividade'), actividade.id])
                redirect actividade
            }
            '*'{ respond actividade, [status: OK] }
        }
    }

    def delete(Long id) {
        if (id == null) {
            notFound()
            return
        }

        actividadeService.delete(id)

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'actividade.label', default: 'Actividade'), id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'actividade.label', default: 'Actividade'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
