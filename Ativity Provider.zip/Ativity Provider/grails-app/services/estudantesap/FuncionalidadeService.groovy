package estudantesap

import grails.gorm.services.Service

@Service(Funcionalidade)
interface FuncionalidadeService {

    Funcionalidade get(Serializable id)

    List<Funcionalidade> list(Map args)

    Long count()

    void delete(Serializable id)

    Funcionalidade save(Funcionalidade funcionalidade)

}