package estudantesap

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ActividadeSpec extends Specification implements DomainUnitTest<Actividade> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
