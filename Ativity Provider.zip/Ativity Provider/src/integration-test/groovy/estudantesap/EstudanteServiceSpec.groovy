package estudantesap

import grails.testing.mixin.integration.Integration
import grails.gorm.transactions.Rollback
import spock.lang.Specification
import org.hibernate.SessionFactory

@Integration
@Rollback
class EstudanteServiceSpec extends Specification {

    EstudanteService estudanteService
    SessionFactory sessionFactory

    private Long setupData() {
        // TODO: Populate valid domain instances and return a valid ID
        //new Estudante(...).save(flush: true, failOnError: true)
        //new Estudante(...).save(flush: true, failOnError: true)
        //Estudante estudante = new Estudante(...).save(flush: true, failOnError: true)
        //new Estudante(...).save(flush: true, failOnError: true)
        //new Estudante(...).save(flush: true, failOnError: true)
        assert false, "TODO: Provide a setupData() implementation for this generated test suite"
        //estudante.id
    }

    void "test get"() {
        setupData()

        expect:
        estudanteService.get(1) != null
    }

    void "test list"() {
        setupData()

        when:
        List<Estudante> estudanteList = estudanteService.list(max: 2, offset: 2)

        then:
        estudanteList.size() == 2
        assert false, "TODO: Verify the correct instances are returned"
    }

    void "test count"() {
        setupData()

        expect:
        estudanteService.count() == 5
    }

    void "test delete"() {
        Long estudanteId = setupData()

        expect:
        estudanteService.count() == 5

        when:
        estudanteService.delete(estudanteId)
        sessionFactory.currentSession.flush()

        then:
        estudanteService.count() == 4
    }

    void "test save"() {
        when:
        assert false, "TODO: Provide a valid instance to save"
        Estudante estudante = new Estudante()
        estudanteService.save(estudante)

        then:
        estudante.id != null
    }
}
