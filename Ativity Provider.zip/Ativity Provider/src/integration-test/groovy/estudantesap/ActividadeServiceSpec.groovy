package estudantesap

import grails.testing.mixin.integration.Integration
import grails.gorm.transactions.Rollback
import spock.lang.Specification
import org.hibernate.SessionFactory

@Integration
@Rollback
class ActividadeServiceSpec extends Specification {

    ActividadeService actividadeService
    SessionFactory sessionFactory

    private Long setupData() {
        // TODO: Populate valid domain instances and return a valid ID
        //new Actividade(...).save(flush: true, failOnError: true)
        //new Actividade(...).save(flush: true, failOnError: true)
        //Actividade actividade = new Actividade(...).save(flush: true, failOnError: true)
        //new Actividade(...).save(flush: true, failOnError: true)
        //new Actividade(...).save(flush: true, failOnError: true)
        assert false, "TODO: Provide a setupData() implementation for this generated test suite"
        //actividade.id
    }

    void "test get"() {
        setupData()

        expect:
        actividadeService.get(1) != null
    }

    void "test list"() {
        setupData()

        when:
        List<Actividade> actividadeList = actividadeService.list(max: 2, offset: 2)

        then:
        actividadeList.size() == 2
        assert false, "TODO: Verify the correct instances are returned"
    }

    void "test count"() {
        setupData()

        expect:
        actividadeService.count() == 5
    }

    void "test delete"() {
        Long actividadeId = setupData()

        expect:
        actividadeService.count() == 5

        when:
        actividadeService.delete(actividadeId)
        sessionFactory.currentSession.flush()

        then:
        actividadeService.count() == 4
    }

    void "test save"() {
        when:
        assert false, "TODO: Provide a valid instance to save"
        Actividade actividade = new Actividade()
        actividadeService.save(actividade)

        then:
        actividade.id != null
    }
}
