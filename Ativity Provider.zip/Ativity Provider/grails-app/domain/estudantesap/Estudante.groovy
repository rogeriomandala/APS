package estudantesap

class Estudante {

    String documento
    String nome
    String apelido
    String nomeCompleto


    public static List CONSTANTES = [
    [documento:"ghgc",nome:'Carlos',apelido:"Sabao"],
    [documento:"6523",nome:'Sebastiao',apelido:"Tivane"],
    [documento:"sdsd",nome:'Joana',apelido:"Cabral"],
    ]

    String toString(){
        return getNomeCompleto()
    }


    String getNomeCompleto(){
        String val = "${nome} ${apelido ?:''}"
        this.nomeCompleto = val
        return val
    }

    def dependencias(){
        if (!this?.id){
            getNomeCompleto()
        }
    }

    def beforeValidate(){
        dependencias()
    }

    def beforeInsert(){
        dependencias()
    }

    static constraints = {
        documento(unique:true)
        nome()
        apelido(nullable:false)
    }

}
