package estudantesap

import grails.testing.mixin.integration.Integration
import grails.gorm.transactions.Rollback
import spock.lang.Specification
import org.hibernate.SessionFactory

@Integration
@Rollback
class TecnologiaServiceSpec extends Specification {

    TecnologiaService tecnologiaService
    SessionFactory sessionFactory

    private Long setupData() {
        // TODO: Populate valid domain instances and return a valid ID
        //new Tecnologia(...).save(flush: true, failOnError: true)
        //new Tecnologia(...).save(flush: true, failOnError: true)
        //Tecnologia tecnologia = new Tecnologia(...).save(flush: true, failOnError: true)
        //new Tecnologia(...).save(flush: true, failOnError: true)
        //new Tecnologia(...).save(flush: true, failOnError: true)
        assert false, "TODO: Provide a setupData() implementation for this generated test suite"
        //tecnologia.id
    }

    void "test get"() {
        setupData()

        expect:
        tecnologiaService.get(1) != null
    }

    void "test list"() {
        setupData()

        when:
        List<Tecnologia> tecnologiaList = tecnologiaService.list(max: 2, offset: 2)

        then:
        tecnologiaList.size() == 2
        assert false, "TODO: Verify the correct instances are returned"
    }

    void "test count"() {
        setupData()

        expect:
        tecnologiaService.count() == 5
    }

    void "test delete"() {
        Long tecnologiaId = setupData()

        expect:
        tecnologiaService.count() == 5

        when:
        tecnologiaService.delete(tecnologiaId)
        sessionFactory.currentSession.flush()

        then:
        tecnologiaService.count() == 4
    }

    void "test save"() {
        when:
        assert false, "TODO: Provide a valid instance to save"
        Tecnologia tecnologia = new Tecnologia()
        tecnologiaService.save(tecnologia)

        then:
        tecnologia.id != null
    }
}
