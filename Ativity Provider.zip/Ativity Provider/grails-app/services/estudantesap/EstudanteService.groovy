package estudantesap

import grails.gorm.services.Service

@Service(Estudante)
interface EstudanteService {

    Estudante get(Serializable id)

    List<Estudante> list(Map args)

    Long count()

    void delete(Serializable id)

    Estudante save(Estudante estudante)

}