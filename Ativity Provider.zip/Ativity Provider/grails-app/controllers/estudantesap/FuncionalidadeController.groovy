package estudantesap

import grails.validation.ValidationException
import static org.springframework.http.HttpStatus.*

class FuncionalidadeController {

    FuncionalidadeService funcionalidadeService

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond funcionalidadeService.list(params), model:[funcionalidadeCount: funcionalidadeService.count()]
    }

    def show(Long id) {
        respond funcionalidadeService.get(id)
    }

    def create() {
        respond new Funcionalidade(params)
    }

    def save(Funcionalidade funcionalidade) {
        if (funcionalidade == null) {
            notFound()
            return
        }

        try {
            funcionalidadeService.save(funcionalidade)
        } catch (ValidationException e) {
            respond funcionalidade.errors, view:'create'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'funcionalidade.label', default: 'Funcionalidade'), funcionalidade.id])
                redirect funcionalidade
            }
            '*' { respond funcionalidade, [status: CREATED] }
        }
    }

    def edit(Long id) {
        respond funcionalidadeService.get(id)
    }

    def update(Funcionalidade funcionalidade) {
        if (funcionalidade == null) {
            notFound()
            return
        }

        try {
            funcionalidadeService.save(funcionalidade)
        } catch (ValidationException e) {
            respond funcionalidade.errors, view:'edit'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'funcionalidade.label', default: 'Funcionalidade'), funcionalidade.id])
                redirect funcionalidade
            }
            '*'{ respond funcionalidade, [status: OK] }
        }
    }

    def delete(Long id) {
        if (id == null) {
            notFound()
            return
        }

        funcionalidadeService.delete(id)

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'funcionalidade.label', default: 'Funcionalidade'), id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'funcionalidade.label', default: 'Funcionalidade'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
