package estudantesap

import grails.validation.ValidationException
import static org.springframework.http.HttpStatus.*

class EstudanteController {

    EstudanteService estudanteService

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond estudanteService.list(params), model:[estudanteCount: estudanteService.count()]
    }

    def show(Long id) {
        respond estudanteService.get(id)
    }

    def create() {
        respond new Estudante(params)
    }

    def save(Estudante estudante) {
        if (estudante == null) {
            notFound()
            return
        }

        try {
            estudanteService.save(estudante)
        } catch (ValidationException e) {
            respond estudante.errors, view:'create'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'estudante.label', default: 'Estudante'), estudante.id])
                redirect estudante
            }
            '*' { respond estudante, [status: CREATED] }
        }
    }

    def edit(Long id) {
        respond estudanteService.get(id)
    }

    def update(Estudante estudante) {
        if (estudante == null) {
            notFound()
            return
        }

        try {
            estudanteService.save(estudante)
        } catch (ValidationException e) {
            respond estudante.errors, view:'edit'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'estudante.label', default: 'Estudante'), estudante.id])
                redirect estudante
            }
            '*'{ respond estudante, [status: OK] }
        }
    }

    def delete(Long id) {
        if (id == null) {
            notFound()
            return
        }

        estudanteService.delete(id)

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'estudante.label', default: 'Estudante'), id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'estudante.label', default: 'Estudante'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
