package estudantesap

import grails.gorm.services.Service

@Service(Atributo)
interface AtributoService {

    Atributo get(Serializable id)

    List<Atributo> list(Map args)

    Long count()

    void delete(Serializable id)

    Atributo save(Atributo atributo)

}