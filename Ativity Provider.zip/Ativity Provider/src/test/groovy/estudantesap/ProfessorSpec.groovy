package estudantesap

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ProfessorSpec extends Specification implements DomainUnitTest<Professor> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
