package estudantesap

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class TecnologiaSpec extends Specification implements DomainUnitTest<Tecnologia> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
