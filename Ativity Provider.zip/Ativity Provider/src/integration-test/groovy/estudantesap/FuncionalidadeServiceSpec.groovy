package estudantesap

import grails.testing.mixin.integration.Integration
import grails.gorm.transactions.Rollback
import spock.lang.Specification
import org.hibernate.SessionFactory

@Integration
@Rollback
class FuncionalidadeServiceSpec extends Specification {

    FuncionalidadeService funcionalidadeService
    SessionFactory sessionFactory

    private Long setupData() {
        // TODO: Populate valid domain instances and return a valid ID
        //new Funcionalidade(...).save(flush: true, failOnError: true)
        //new Funcionalidade(...).save(flush: true, failOnError: true)
        //Funcionalidade funcionalidade = new Funcionalidade(...).save(flush: true, failOnError: true)
        //new Funcionalidade(...).save(flush: true, failOnError: true)
        //new Funcionalidade(...).save(flush: true, failOnError: true)
        assert false, "TODO: Provide a setupData() implementation for this generated test suite"
        //funcionalidade.id
    }

    void "test get"() {
        setupData()

        expect:
        funcionalidadeService.get(1) != null
    }

    void "test list"() {
        setupData()

        when:
        List<Funcionalidade> funcionalidadeList = funcionalidadeService.list(max: 2, offset: 2)

        then:
        funcionalidadeList.size() == 2
        assert false, "TODO: Verify the correct instances are returned"
    }

    void "test count"() {
        setupData()

        expect:
        funcionalidadeService.count() == 5
    }

    void "test delete"() {
        Long funcionalidadeId = setupData()

        expect:
        funcionalidadeService.count() == 5

        when:
        funcionalidadeService.delete(funcionalidadeId)
        sessionFactory.currentSession.flush()

        then:
        funcionalidadeService.count() == 4
    }

    void "test save"() {
        when:
        assert false, "TODO: Provide a valid instance to save"
        Funcionalidade funcionalidade = new Funcionalidade()
        funcionalidadeService.save(funcionalidade)

        then:
        funcionalidade.id != null
    }
}
