package estudantesap

import grails.gorm.transactions.Transactional



import grails.rest.*
import grails.converters.*


@Transactional
class ActivityProviderService {

    def doPost(Actividade actividade,Long studentId) {
        Estudante.get(id)

        Actividade.list()
    }


    def efectuarPost(Long id){
        def message = []
        println params
        Deploy  dep
        if (actividade){
            dep = Deploy.findByActividadeAndStudent(actividade,studentId)
            if (!dep ){
                message << [msg:"estudente inexistente"]
                render message  as JSON
                return
            }
        }else{
                message << [msg:"inexistente"]
                render message  as JSON
                return
        }
        render dep as JSON

    }


    def obterAnalytics(){
        ActividadeEstudante.list()
    }


}
