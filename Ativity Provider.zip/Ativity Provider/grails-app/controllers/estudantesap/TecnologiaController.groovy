package estudantesap

import grails.validation.ValidationException
import static org.springframework.http.HttpStatus.*

class TecnologiaController {

    TecnologiaService tecnologiaService

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond tecnologiaService.list(params), model:[tecnologiaCount: tecnologiaService.count()]
    }

    def show(Long id) {
        respond tecnologiaService.get(id)
    }

    def create() {
        respond new Tecnologia(params)
    }

    def save(Tecnologia tecnologia) {
        if (tecnologia == null) {
            notFound()
            return
        }

        try {
            tecnologiaService.save(tecnologia)
        } catch (ValidationException e) {
            respond tecnologia.errors, view:'create'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'tecnologia.label', default: 'Tecnologia'), tecnologia.id])
                redirect tecnologia
            }
            '*' { respond tecnologia, [status: CREATED] }
        }
    }

    def edit(Long id) {
        respond tecnologiaService.get(id)
    }

    def update(Tecnologia tecnologia) {
        if (tecnologia == null) {
            notFound()
            return
        }

        try {
            tecnologiaService.save(tecnologia)
        } catch (ValidationException e) {
            respond tecnologia.errors, view:'edit'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'tecnologia.label', default: 'Tecnologia'), tecnologia.id])
                redirect tecnologia
            }
            '*'{ respond tecnologia, [status: OK] }
        }
    }

    def delete(Long id) {
        if (id == null) {
            notFound()
            return
        }

        tecnologiaService.delete(id)

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'tecnologia.label', default: 'Tecnologia'), id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'tecnologia.label', default: 'Tecnologia'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
