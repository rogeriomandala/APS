package estudantesap

class Professor {

    String documento
    String nome
    String apelido
    String nomeCompleto

    public static List CONSTANTES = [
    [documento:"xpt",nome:'Pedro',apelido:"Simeao"],
    [documento:"asa",nome:'Joaquim',apelido:"Sitoe"],
    [documento:"fff",nome:'Ana',apelido:"Teresa Dias"],
    [documento:"hhg",nome:'Catarina',apelido:"Conceicao"]
    ]

    String getNomeCompleto(){
        String val = "${nome} ${apelido ?:''}"
        this.nomeCompleto = val
        return val
    }

    public String toString()
    {
        return getNomeCompleto()
    }
    def dependencias(){
        if (!this?.id){
            getNomeCompleto()
        }
    }

    def beforeValidate(){
        dependencias()
    }

    def beforeInsert(){
        dependencias()
    }

    static constraints = {
        documento(unique:true)
        nome()
        apelido(nullable:false)
    }
}
