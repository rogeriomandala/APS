package estudantesap

class Funcionalidade {

    static hasMany = [atributos:Atributo,tecnologias:Tecnologia]
    static belongsTo = [Actividade]
    Actividade actividade
    String nome 
    String descricao
    String entidade
    boolean criar = Boolean.FALSE
    boolean ler = Boolean.FALSE
    boolean actualizar = Boolean.FALSE
    boolean remover = Boolean.FALSE
    byte[] modeloRelacional
    byte[] aplicacaoBase

    String toString(){
        return nome
    }

    public static List CONSTANTES = [
    [nome:"Produtos",entidade:"Produto",descricao:"CRUD de Criacao De Um Sistema para Empresa"],
    [nome:"Leitura",entidade:"Stock",descricao:"CRUD para Leitura de Produtos"],
    [nome:"Delete",entidade:"Armazem",descricao:"Remover Produtos de Uma base de dados"]
    ]


    static constraints = {
        actividade()
        nome()
        descricao(widget:'textarea',nullable:true,blank:true)
        entidade()
        criar()
        ler()
        actualizar()
        remover()
        modeloRelacional(nullable:true)
        aplicacaoBase(nullable:true)
    }
}
