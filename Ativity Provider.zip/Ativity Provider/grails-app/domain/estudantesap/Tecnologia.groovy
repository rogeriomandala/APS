package estudantesap

class Tecnologia {

    String nome 

    static String[] CONSTANTES = ["Node",".NET VB",".NET C#","C++",
    "PHP","Ruby & Rails ","Groovy & Grails","Elixir"]

    String toString(){
        return nome
    }


    static constraints = {
        nome(unique:true)
    }

}
