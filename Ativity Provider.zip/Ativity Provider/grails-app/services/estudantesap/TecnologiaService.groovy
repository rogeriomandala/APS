package estudantesap

import grails.gorm.services.Service

@Service(Tecnologia)
interface TecnologiaService {

    Tecnologia get(Serializable id)

    List<Tecnologia> list(Map args)

    Long count()

    void delete(Serializable id)

    Tecnologia save(Tecnologia tecnologia)

}