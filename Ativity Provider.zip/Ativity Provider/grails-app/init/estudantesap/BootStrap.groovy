package estudantesap

class BootStrap {

    def init = { servletContext ->
        criarTecnologias()
        criarProfessores()
        criarEstudantes()
        criarActividades()
        criarFuncionalidades()
    }

    def criarFuncionalidades(){
        Funcionalidade.CONSTANTES.each{ v ->
            Funcionalidade p = Funcionalidade.findByNome(v?.nome)
            if (p){
                return 
            }
            p = new Funcionalidade(v)
            p.actividade = randomFromList(Actividade.list())
            if (!p.save(flush:true)){
                p?.errors?.each{
                    println it
                }
            }
        }

    }
    def criarActividades(){
        Actividade.CONSTANTES.each{ v ->
            Actividade p = Actividade.findByTitulo(v?.titulo)
            if (p){
                return 
            }
            p = new Actividade(v)

            1..3?.each{ num ->
                p.addToTecnologias( randomFromList(Tecnologia.list()))
            }
            if (!p.save(flush:true)){
                p?.errors?.each{
                    println it
                }
            }
        }
    }

    def randomFromList(lista){
        if (!lista){
            return null
        }
        List list = new ArrayList(lista)

        if (!list || list?.size() < 1){
            return null
        }


        Collections.shuffle list
        return list?.first()
    }

    def criarProfessores(){
        Professor.CONSTANTES.each{ v ->
            Professor p = Professor.findByDocumento(v?.documento)
            if (p){
                return 
            }
            p = new Professor(v)
            if (!p.save(flush:true)){
                p?.errors?.each{
                    println it
                }
            }
        }

    }
    def criarEstudantes(){
        Estudante.CONSTANTES.each{ v ->
            Estudante p = Estudante.findByDocumento(v?.documento)
            if (p){
                return 
            }
            p = new Estudante(v)
            if (!p.save(flush:true)){
                p?.errors?.each{
                    println it
                }
            }
        }
        
    }
    def criarTecnologias(){
        Tecnologia.CONSTANTES.each{String nome  ->
            Tecnologia p = Tecnologia.findByNome(nome)
            if (p){
                return 
            }
            p = new Tecnologia(nome:nome)
            if (!p.save(flush:true)){
                p?.errors?.each{
                    println it
                }
            }
        }
    }

    def destroy = {
    }
}
