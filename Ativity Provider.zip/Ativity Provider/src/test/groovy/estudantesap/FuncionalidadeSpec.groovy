package estudantesap

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class FuncionalidadeSpec extends Specification implements DomainUnitTest<Funcionalidade> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
