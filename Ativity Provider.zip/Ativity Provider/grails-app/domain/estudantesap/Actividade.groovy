package estudantesap

class Actividade {

    static hasMany = [funcionalidades:Funcionalidade,tecnologias:Tecnologia]

    Date data = new Date()
    String titulo
    String descricao

    public static List CONSTANTES = [
    [titulo:"Sistema Empresaria",descricao:"CRUD de Criacao De Um Sistema para Empresa"],
    [titulo:"Leitura Produtos",descricao:"CRUD para Leitura de Produtos"],
    [titulo:"Delete testar",descricao:"Remover Produtos de Uma base de dados"]
    ]


    static constraints = {
        data()
        titulo()
        descricao(widget:'textarea',nullable:true,blank:true)
    }
}
