package estudantesap

import grails.gorm.services.Service

@Service(Actividade)
interface ActividadeService {

    Actividade get(Serializable id)

    List<Actividade> list(Map args)

    Long count()

    void delete(Serializable id)

    Actividade save(Actividade actividade)

}