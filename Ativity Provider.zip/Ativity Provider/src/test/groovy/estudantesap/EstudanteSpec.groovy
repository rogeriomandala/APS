package estudantesap

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class EstudanteSpec extends Specification implements DomainUnitTest<Estudante> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
