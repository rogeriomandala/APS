package estudantesap

class HomeController {

    def index() { }
}
