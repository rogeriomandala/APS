package estudantesap

class Atributo {

    static belongsTo = [Funcionalidade]

    Funcionalidade funcionalidade
    String nome 

    String toString(){
        return nome
    }

    static constraints = {
        funcionalidade()
        nome()
    }
}
