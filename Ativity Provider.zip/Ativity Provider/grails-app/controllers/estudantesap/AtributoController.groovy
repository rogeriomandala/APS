package estudantesap

import grails.validation.ValidationException
import static org.springframework.http.HttpStatus.*

class AtributoController {

    AtributoService atributoService

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond atributoService.list(params), model:[atributoCount: atributoService.count()]
    }

    def show(Long id) {
        respond atributoService.get(id)
    }

    def create() {
        respond new Atributo(params)
    }

    def save(Atributo atributo) {
        if (atributo == null) {
            notFound()
            return
        }

        try {
            atributoService.save(atributo)
        } catch (ValidationException e) {
            respond atributo.errors, view:'create'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'atributo.label', default: 'Atributo'), atributo.id])
                redirect atributo
            }
            '*' { respond atributo, [status: CREATED] }
        }
    }

    def edit(Long id) {
        respond atributoService.get(id)
    }

    def update(Atributo atributo) {
        if (atributo == null) {
            notFound()
            return
        }

        try {
            atributoService.save(atributo)
        } catch (ValidationException e) {
            respond atributo.errors, view:'edit'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'atributo.label', default: 'Atributo'), atributo.id])
                redirect atributo
            }
            '*'{ respond atributo, [status: OK] }
        }
    }

    def delete(Long id) {
        if (id == null) {
            notFound()
            return
        }

        atributoService.delete(id)

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'atributo.label', default: 'Atributo'), id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'atributo.label', default: 'Atributo'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
