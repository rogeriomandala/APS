package estudantesap

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class ActivityProviderServiceSpec extends Specification implements ServiceUnitTest<ActivityProviderService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
