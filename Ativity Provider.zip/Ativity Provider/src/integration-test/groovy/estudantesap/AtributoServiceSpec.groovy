package estudantesap

import grails.testing.mixin.integration.Integration
import grails.gorm.transactions.Rollback
import spock.lang.Specification
import org.hibernate.SessionFactory

@Integration
@Rollback
class AtributoServiceSpec extends Specification {

    AtributoService atributoService
    SessionFactory sessionFactory

    private Long setupData() {
        // TODO: Populate valid domain instances and return a valid ID
        //new Atributo(...).save(flush: true, failOnError: true)
        //new Atributo(...).save(flush: true, failOnError: true)
        //Atributo atributo = new Atributo(...).save(flush: true, failOnError: true)
        //new Atributo(...).save(flush: true, failOnError: true)
        //new Atributo(...).save(flush: true, failOnError: true)
        assert false, "TODO: Provide a setupData() implementation for this generated test suite"
        //atributo.id
    }

    void "test get"() {
        setupData()

        expect:
        atributoService.get(1) != null
    }

    void "test list"() {
        setupData()

        when:
        List<Atributo> atributoList = atributoService.list(max: 2, offset: 2)

        then:
        atributoList.size() == 2
        assert false, "TODO: Verify the correct instances are returned"
    }

    void "test count"() {
        setupData()

        expect:
        atributoService.count() == 5
    }

    void "test delete"() {
        Long atributoId = setupData()

        expect:
        atributoService.count() == 5

        when:
        atributoService.delete(atributoId)
        sessionFactory.currentSession.flush()

        then:
        atributoService.count() == 4
    }

    void "test save"() {
        when:
        assert false, "TODO: Provide a valid instance to save"
        Atributo atributo = new Atributo()
        atributoService.save(atributo)

        then:
        atributo.id != null
    }
}
